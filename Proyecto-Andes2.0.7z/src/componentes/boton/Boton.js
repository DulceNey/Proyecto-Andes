import React from 'react';
import ModalContainer from '../ModalContainer';

const Boton = ({visibleModal,setVisibleModal}) => {
return (
    <>
    
    </>
)
}

export default Boton