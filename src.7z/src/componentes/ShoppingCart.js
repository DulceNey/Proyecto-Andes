import React from 'react';
import { TYPES } from './acciones';
// import { useReducer} from 'react';
// import { shoppingInitialState,shoppingReducer } from './shoppingReducer';
import Productos from './Productos';
import ItemsCarrito from './ItemsCarrito';
import { useContext } from 'react';
import { ToursContext } from './ToursProvider';



const ShoppingCart =() => {

  const {state,handleActions} =useContext(ToursContext);
  const {addToCart,deleteFromCart}=handleActions;
  const {products,cart}=state;
     // const [state, dispatch] = useReducer(shoppingReducer,shoppingInitialState);
    // const {products,cart}=state;

    
      // const addToCart = (id)=>{
      //   dispatch({type:TYPES.ADD_TO_CART, payload:id})
        
      // };
      // const deleteFromCart = (id,all=false)=>{
      //   if (all) {
      //     dispatch({type:TYPES.REMOVE_ALL_PRODUCTS, payload:id})
      //   } else {
          
      //     dispatch({type:TYPES.REMOVE_ONE_PRODUCT, payload:id})
      //   }
      // };
           
           
  return (
    <>
    {/* <div className='flex flex-auto justify-around gap-12  bg-orange-500 border-2'>
        {state.map(product => <Productos key={tours.id} data={tours} addToCart={addToCart}/>)}
     </div>  */}
     
     <h3>carrito</h3>

     <div className='w-4/6 h-screen flex-1 flex-grow flex-col justify-center items-center  bg-slate-200 border-2'>
        {products.map((product)=><ItemsCarrito key={state.id} data={state} addToCart={addToCart} deleteFromCart={deleteFromCart} />)}
     </div>

  

    </>
  )
}

export default ShoppingCart