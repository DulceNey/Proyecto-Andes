import React from 'react';
import { useReducer } from 'react';
import { shoppingInitialState,shoppingReducer } from './shoppingReducer';
import { createContext,useContext } from 'react';
import { TYPES } from './acciones';

export const ToursContext=createContext()

const ToursProvider = ({children}) => {
     const [state, dispatch] = useReducer(shoppingReducer,shoppingInitialState);
     const {products,cart}=state;
     const material={
        state,
        dispatch,
       
     }
     
    return (
<ToursContext.Provider value={material}>
  {children}
</ToursContext.Provider>

  )

}

export default ToursProvider